Next steps
==========

That brings us to the end of the tutorial!  Hopefully by now you have a good
feel for the capabilities of MicroPython on the ESP8266 and understand how to
control both the WiFi and IO aspects of the chip.

There are many features that were not covered in this tutorial.  The best way
to learn about them is to read the full documentation of the modules, and to
experiment!

Good luck creating your Internet of Things devices!
