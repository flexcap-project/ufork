This is an example of a user C module that includes subpackages.
